from __future__ import annotations
import math
import os
import sys
from collections import deque
from typing import Iterable
import numpy as np
_DEFAULT = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'mapdata', 'office_map.npz')
ALT_RAY_OFFSET_M = 0.12 - 0.01
MAX_RAY_DISTANCE_M = 100.0

class OfficeMap:

    def __init__(self, path: str=_DEFAULT):
        z = np.load(path)
        self.shape = tuple((int(v) for v in z['shape']))
        self.origin = np.asarray(z['origin'], dtype=np.float64)
        self.res = float(z['res'][0])
        nz, ny, nx = self.shape
        self.surface = np.unpackbits(z['surface_bits'])[:nz * ny * nx].reshape(nz, ny, nx).astype(bool)
        self.clear_cm = np.asarray(z['clear_cm'])
        self.surf_off_mm = np.asarray(z['surf_off_mm'])
        self._inv = 1.0 / self.res
        idx = np.arange(nz, dtype=np.int16)[:, None, None]
        vals = np.where(self.surface, idx, np.int16(-1))
        self._col = np.maximum.accumulate(vals, axis=0).transpose(1, 2, 0).copy()

    def to_index(self, xyz) -> np.ndarray:
        a = np.asarray(xyz, dtype=np.float64)
        return np.floor((a - self.origin) * self._inv).astype(np.int64)

    def in_bounds(self, ijk) -> np.ndarray:
        a = np.atleast_2d(np.asarray(ijk))
        nz, ny, nx = self.shape
        return (a[:, 0] >= 0) & (a[:, 0] < nx) & (a[:, 1] >= 0) & (a[:, 1] < ny) & (a[:, 2] >= 0) & (a[:, 2] < nz)

    def clearance(self, xyz) -> np.ndarray:
        a = np.atleast_2d(np.asarray(xyz, dtype=np.float64))
        ijk = self.to_index(a)
        ok = self.in_bounds(ijk)
        out = np.zeros(len(a), dtype=np.float64)
        if ok.any():
            g = ijk[ok]
            out[ok] = self.clear_cm[g[:, 2], g[:, 1], g[:, 0]] / 100.0
        return out if out.size > 1 else float(out[0])

    def predict_tof(self, xyz) -> np.ndarray:
        a = np.atleast_2d(np.asarray(xyz, dtype=np.float64))
        origin_z = a[:, 2] - ALT_RAY_OFFSET_M
        ijk = self.to_index(np.column_stack([a[:, 0], a[:, 1], origin_z]))
        nz, ny, nx = self.shape
        out = np.full(len(a), MAX_RAY_DISTANCE_M, dtype=np.float64)
        ok = (ijk[:, 0] >= 0) & (ijk[:, 0] < nx) & (ijk[:, 1] >= 0) & (ijk[:, 1] < ny) & (ijk[:, 2] >= 0) & (ijk[:, 2] < nz)
        if ok.any():
            g = ijk[ok]
            k_surf = self._col[g[:, 1], g[:, 0], g[:, 2]].astype(np.int64)
            found = k_surf >= 0
            ks = np.where(found, k_surf, 0)
            z_surf = self.origin[2] + ks * self.res + self.surf_off_mm[ks, g[:, 1], g[:, 0]] / 1000.0
            vals = np.where(found, a[ok, 2] - z_surf, MAX_RAY_DISTANCE_M)
            out[ok] = vals
        return out if out.size > 1 else float(out[0])

    def segment_hits(self, start, end) -> bool:
        s = np.asarray(start, dtype=np.float64)
        e = np.asarray(end, dtype=np.float64)
        d = e - s
        n = float(np.linalg.norm(d))
        if n < 1e-09:
            ijk = self.to_index(s)
            return bool(self.in_bounds(ijk)[0]) and bool(self.surface[ijk[2], ijk[1], ijk[0]])
        steps = int(n * self._inv * 2.0) + 2
        ts = np.linspace(0.0, 1.0, steps)
        pts = s[None, :] + ts[:, None] * d[None, :]
        ijk = self.to_index(pts)
        nz, ny, nx = self.shape
        ok = (ijk[:, 0] >= 0) & (ijk[:, 0] < nx) & (ijk[:, 1] >= 0) & (ijk[:, 1] < ny) & (ijk[:, 2] >= 0) & (ijk[:, 2] < nz)
        if not ok.any():
            return False
        g = ijk[ok]
        return bool(self.surface[g[:, 2], g[:, 1], g[:, 0]].any())

    def path_clearance(self, start, end, samples: int=0) -> float:
        s = np.asarray(start, dtype=np.float64)
        e = np.asarray(end, dtype=np.float64)
        n = float(np.linalg.norm(e - s))
        k = samples or max(2, int(n * self._inv) + 2)
        pts = s[None, :] + np.linspace(0.0, 1.0, k)[:, None] * (e - s)[None, :]
        return float(np.min(self.clearance(pts)))
CTRL_DT = 0.02
SPEED = 3.0
DEAD_ZONE = 0.05
SLEW_PER_SEC = 4.0
SPAWN_Z = 0.05
PLANT_GAIN = 0.893
PLANT_TAU = 0.33
YAW_RATE_MAX = 2.05
YAW_GAIN = 3.141
I_SIN_YAW, I_COS_YAW = (2, 3)
I_VF, I_VR, I_VD = (4, 5, 6)
I_TOF, I_HEIGHT, I_AGE, I_VALID = (10, 11, 13, 14)

def body_to_world(vf: float, vr: float, yaw: float) -> tuple[float, float]:
    c, s = (math.cos(yaw), math.sin(yaw))
    return (vf * c + vr * s, vf * s - vr * c)

class EgoEstimator:

    def __init__(self, *, use_plant_model: bool=False, trapezoid: bool=True, history: int=16):
        self.use_plant_model = use_plant_model
        self.trapezoid = trapezoid
        self._hist = history
        self.reset()

    def reset(self) -> None:
        self.t = 0.0
        self.pos = np.array([0.0, 0.0, SPAWN_Z], dtype=np.float64)
        self.vel = np.zeros(3, dtype=np.float64)
        self.yaw = 0.0
        self.have_fix = False
        self._rc = np.zeros(4, dtype=np.float64)
        self._last_age = None
        self._t_packet = 0.0
        self._v_packet = np.zeros(3, dtype=np.float64)
        self._pos_packet = np.array([0.0, 0.0, SPAWN_Z], dtype=np.float64)
        self._yaw_packet = 0.0
        self.pose_log: deque = deque(maxlen=self._hist)

    def _advance_sticks(self, action) -> np.ndarray:
        rc = np.asarray(action, dtype=np.float64).copy()
        rc[np.abs(rc) < DEAD_ZONE] = 0.0
        step = SLEW_PER_SEC * CTRL_DT
        self._rc = self._rc + np.clip(rc - self._rc, -step, step)
        return self._rc

    def _setpoint(self, rc: np.ndarray, yaw: float) -> np.ndarray:
        vx, vy = body_to_world(rc[1], rc[0], yaw)
        return np.array([SPEED * vx, SPEED * vy, SPEED * rc[2]], dtype=np.float64)

    def _propagate(self, pos, vel, yaw, rc, dt):
        yaw = yaw + float(np.clip(rc[3] * YAW_GAIN, -YAW_RATE_MAX, YAW_RATE_MAX)) * dt
        if self.use_plant_model:
            target = PLANT_GAIN * self._setpoint(rc, yaw)
            new_vel = vel + (target - vel) * (1.0 - math.exp(-dt / PLANT_TAU))
        else:
            new_vel = vel
        return (pos + 0.5 * (vel + new_vel) * dt, new_vel, yaw)

    def update(self, state, last_action) -> None:
        state = np.asarray(state, dtype=np.float64)
        rc = self._advance_sticks(last_action)
        self.t += CTRL_DT
        age = float(state[I_AGE])
        valid = float(state[I_VALID]) > 0.5
        fresh = valid and (self._last_age is None or age < self._last_age - 1e-09)
        self._last_age = age
        if fresh:
            self._absorb_packet(state, age)
        pos, vel, yaw = (self._pos_packet.copy(), self._v_packet.copy(), self._yaw_packet)
        n = min(int(round(max(0.0, self.t - self._t_packet) / CTRL_DT)), self._hist)
        for k in range(n):
            j = len(self.pose_log) - n + k
            rc_k = self.pose_log[j][3] if 0 <= j < len(self.pose_log) else rc
            pos, vel, yaw = self._propagate(pos, vel, yaw, rc_k, CTRL_DT)
        self.pos, self.vel, self.yaw = (pos, vel, yaw)
        if self.have_fix:
            self.pos[2] = self._pos_packet[2] + self.vel[2] * (self.t - self._t_packet)
        self.pose_log.append((self.t, self.pos.copy(), self.yaw, rc.copy()))

    def _absorb_packet(self, state, age: float) -> None:
        t_pkt = self.t - age
        yaw = math.atan2(float(state[I_SIN_YAW]), float(state[I_COS_YAW]))
        vx, vy = body_to_world(float(state[I_VF]), float(state[I_VR]), yaw)
        v_new = np.array([vx, vy, -float(state[I_VD])])
        if not self.have_fix:
            self._pos_packet = np.array([0.0, 0.0, float(state[I_HEIGHT]) + SPAWN_Z])
            self.have_fix = True
        else:
            dt = max(t_pkt - self._t_packet, 0.0)
            step = 0.5 * (self._v_packet + v_new) * dt if self.trapezoid else self._v_packet * dt
            self._pos_packet = self._pos_packet + step
            self._pos_packet[2] = float(state[I_HEIGHT]) + SPAWN_Z
        self._v_packet = v_new
        self._yaw_packet = yaw
        self._t_packet = t_pkt

class MapLocalizer:
    HULL = 0.16
    TOF_SIGMA = 0.13
    TOF_OUTLIER = 0.35
    ALIVE_FLOOR = 0.02
    DRIFT_PER_M = 0.012
    ROUGHEN = 0.06
    SEED_Z = 1.5
    START_Z = 0.8

    def __init__(self, office_map, n: int=16384, seed: int=0):
        self.om = office_map
        self.n0 = n
        self.rng = np.random.default_rng(seed)
        self.reset()

    def reset(self) -> None:
        self.n = self.n0
        self.p = None
        self.w = None
        self._anchor = None
        self.converged = False

    def _seed_cloud(self) -> None:
        om = self.om
        lo = om.origin[:2] + 0.35
        hi = om.origin[:2] + np.array([om.shape[2], om.shape[1]]) * om.res - 0.35
        keep = []
        for _ in range(24):
            pts = self.rng.uniform(lo, hi, (self.n0, 2))
            probe = np.column_stack([pts, np.full(len(pts), self.SEED_Z)])
            keep.append(pts[om.clearance(probe) > self.HULL])
            if sum((len(k) for k in keep)) >= self.n0:
                break
        pts = np.concatenate(keep, axis=0)[:self.n0]
        self.p = pts
        self.n = len(pts)
        self.w = np.full(self.n, 1.0 / self.n)

    def update(self, dr_pos, z: float, tof: float, moved: float) -> None:
        if z < self.START_Z:
            return
        if self.p is None:
            self._seed_cloud()
            self._anchor = np.asarray(dr_pos[:2], dtype=np.float64).copy()
            return
        delta = np.asarray(dr_pos[:2], dtype=np.float64) - self._anchor
        self._anchor = np.asarray(dr_pos[:2], dtype=np.float64).copy()
        self.p = self.p + delta
        if moved > 0:
            self.p = self.p + self.rng.normal(0.0, self.DRIFT_PER_M * moved + 0.0001, self.p.shape)
        probe = np.column_stack([self.p, np.full(len(self.p), z)])
        like = np.where(self.om.clearance(probe) > self.HULL, 1.0, self.ALIVE_FLOOR)
        if 0.0 < tof < 50.0:
            r = np.abs(self.om.predict_tof(probe) - tof)
            gauss = np.exp(-0.5 * (r / self.TOF_SIGMA) ** 2)
            like = like * ((1.0 - self.TOF_OUTLIER) * gauss + self.TOF_OUTLIER)
        self.w = self.w * like
        s = self.w.sum()
        if s <= 0 or not np.isfinite(s):
            self._seed_cloud()
            self.converged = False
            return
        self.w /= s
        if 1.0 / np.sum(self.w ** 2) < 0.5 * self.n:
            self._resample()
        self.converged = bool(self.spread() < 0.35)

    def observe_free_point(self, dr_xy, z: float, radius: float=0.1) -> None:
        if self.p is None:
            return
        offs = self.p - np.asarray(dr_xy, dtype=np.float64)
        probe = np.column_stack([np.asarray(dr_xy) + offs, np.full(len(offs), z)])
        free = self.om.clearance(probe) > radius
        self.w = self.w * np.where(free, 1.0, self.ALIVE_FLOOR)
        s = self.w.sum()
        if s <= 0 or not np.isfinite(s):
            self._seed_cloud()
            return
        self.w /= s
        if 1.0 / np.sum(self.w ** 2) < 0.5 * self.n:
            self._resample()
        self.converged = bool(self.spread() < 0.35)

    def observe_free_segment(self, a_xy, b_xy, z: float, radius: float=0.1) -> None:
        if self.p is None:
            return
        a = np.asarray(a_xy, dtype=np.float64)
        b = np.asarray(b_xy, dtype=np.float64)
        n = float(np.linalg.norm(b - a))
        if n < 0.15 or n > 4.0:
            return
        ts = np.linspace(0.0, 1.0, max(3, int(n / 0.25) + 1))
        pts = a[None, :] + ts[:, None] * (b - a)[None, :]
        offs = self.p - a
        probe = np.concatenate([offs[:, None, :] + pts[None, :, :], np.full((len(offs), len(ts), 1), z)], axis=2)
        clr = self.om.clearance(probe.reshape(-1, 3)).reshape(len(offs), len(ts))
        free = clr.min(axis=1) > radius
        self.w = self.w * np.where(free, 1.0, self.ALIVE_FLOOR)
        s = self.w.sum()
        if s <= 0 or not np.isfinite(s):
            self._seed_cloud()
            return
        self.w /= s
        if 1.0 / np.sum(self.w ** 2) < 0.5 * self.n:
            self._resample()
        self.converged = bool(self.spread() < 0.35)

    def _resample(self) -> None:
        pos = (self.rng.random() + np.arange(self.n)) / self.n
        idx = np.clip(np.searchsorted(np.cumsum(self.w), pos), 0, self.n - 1)
        self.p = self.p[idx] + self.rng.normal(0.0, self.ROUGHEN, (self.n, 2))
        self.w = np.full(self.n, 1.0 / self.n)

    def estimate(self) -> np.ndarray:
        return np.average(self.p, axis=0, weights=self.w)

    def spread(self) -> float:
        d = self.p - self.estimate()
        return float(np.sqrt(np.average(np.sum(d * d, axis=1), weights=self.w)))

    def best_error(self, truth_xy) -> float:
        d = self.p - np.asarray(truth_xy, dtype=np.float64)
        return float(np.sqrt(np.min(np.sum(d * d, axis=1))))

    def modes(self, radius: float=0.5):
        order = np.argsort(-self.w)
        best_c, best_wt = (self.estimate(), 0.0)
        for i in order[:24]:
            m = np.linalg.norm(self.p - self.p[i], axis=1) < radius
            wt = float(self.w[m].sum())
            if wt > best_wt:
                best_wt, best_c = (wt, np.average(self.p[m], axis=0, weights=self.w[m]))
        return (best_c, best_wt)
DT = 1.0 / 50.0
RES, FOCAL = (256.0, 128.0)
K = RES / FOCAL
TGT_W, TGT_H = (0.18, 0.08)
EYE_FWD, EYE_UP = (0.13, 0.05)
SPAWN_Z = 0.05
V_MAX = float(os.environ.get('OFFICE_VMAX', '3.0'))
A_EFF = float(os.environ.get('OFFICE_AEFF', '3.4'))
V_CREEP = float(os.environ.get('OFFICE_V_CREEP', '0.45'))
STALE_MUL = float(os.environ.get('OFFICE_STALE_MUL', '0.55'))
Z_CRUISE = float(os.environ.get('OFFICE_Z_CRUISE', '1.90'))
CLIMB_Z = float(os.environ.get('OFFICE_CLIMB_Z', '1.55'))
REACQ_V = float(os.environ.get('OFFICE_REACQ_V', '1.1'))
YAW_LEAD_S = float(os.environ.get('OFFICE_YAW_LEAD', '0.15'))
REACQ_MAX_S = float(os.environ.get('OFFICE_REACQ_MAX', '1.2'))
SEG_OBS = int(os.environ.get('OFFICE_SEG_OBS', '0'))
R_COMMIT = float(os.environ.get('OFFICE_R_COMMIT', '0.0'))
COMMIT_V = float(os.environ.get('OFFICE_COMMIT_V', '2.0'))
CLIMB_CHASE = float(os.environ.get('OFFICE_CLIMB_CHASE', '0.0'))
Z_CEIL = float(os.environ.get('OFFICE_Z_CEIL', '2.62'))
Z_FLOOR = float(os.environ.get('OFFICE_Z_FLOOR', '1.10'))
VZ_MAX = float(os.environ.get('OFFICE_VZ_MAX', '1.7'))
A_Z = float(os.environ.get('OFFICE_A_Z', '2.5'))
YAW_K = float(os.environ.get('OFFICE_YAW_K', '1.1'))
YAW_MAX = float(os.environ.get('OFFICE_YAW_MAX', '0.68'))
SEARCH_YAW = float(os.environ.get('OFFICE_SEARCH_YAW', '0.50'))
FRESH_S = float(os.environ.get('OFFICE_FRESH_S', '0.30'))
STALE_S = float(os.environ.get('OFFICE_STALE_S', '0.60'))
CONFIRM_S = float(os.environ.get('OFFICE_CONFIRM_S', '0.35'))
GATE_K = float(os.environ.get('OFFICE_GATE_K', '0.25'))
ALPHA = float(os.environ.get('OFFICE_ALPHA', '0.45'))
BETA = float(os.environ.get('OFFICE_BETA', '0.35'))
VT_MAX = float(os.environ.get('OFFICE_VT_MAX', '2.4'))
R_TERM = float(os.environ.get('OFFICE_R_TERM', '0.90'))
DIR_TAU = float(os.environ.get('OFFICE_DIR_TAU', '0.09'))
T_LEAD = float(os.environ.get('OFFICE_T_LEAD', '0.30'))
A_CMD = float(os.environ.get('OFFICE_A_CMD', '10.5'))
TILT_GUARD = float(os.environ.get('OFFICE_TILT_GUARD', '0.55'))
MAP_VETO = int(os.environ.get('OFFICE_MAP_VETO', '0'))
VETO_HORIZON_S = float(os.environ.get('OFFICE_VETO_H', '1.8'))
VETO_CLEAR_M = float(os.environ.get('OFFICE_VETO_CLEAR', '0.38'))
VETO_RISK_TOL = float(os.environ.get('OFFICE_VETO_TOL', '0.10'))
VETO_PARTICLES = int(os.environ.get('OFFICE_VETO_N', '256'))
VETO_REACH_MAX = float(os.environ.get('OFFICE_VETO_REACH', '3.0'))
LOC_N = int(os.environ.get('OFFICE_LOC_N', '8192'))
ALIGN_GATE = float(os.environ.get('OFFICE_ALIGN', '0.95'))
ALIGN_VERT = float(os.environ.get('OFFICE_ALIGN_V', '0.0'))
R_VISUAL = float(os.environ.get('OFFICE_R_VIS', '0.0'))
V_TERM = float(os.environ.get('OFFICE_V_TERM', '1.5'))
K_VIS = float(os.environ.get('OFFICE_K_VIS', '1.2'))
LEAD_MODE = int(os.environ.get('OFFICE_LEAD_MODE', '0'))
LEAD_MAX_S = float(os.environ.get('OFFICE_LEAD_MAX', '4.0'))
LEAD_SPEED_FRAC = float(os.environ.get('OFFICE_LEAD_FRAC', '0.85'))
ROLL_DT = float(os.environ.get('OFFICE_ROLL_DT', '0.06'))
LEG_MODE = int(os.environ.get('OFFICE_LEG', '0'))
LEG_WINDOW_S = float(os.environ.get('OFFICE_LEG_WIN', '1.5'))
LEG_MIN_PTS = int(os.environ.get('OFFICE_LEG_PTS', '5'))
LEG_MIN_SPAN_S = float(os.environ.get('OFFICE_LEG_SPAN', '0.35'))
LEG_MAX_RMS = float(os.environ.get('OFFICE_LEG_RMS', '0.30'))
LEG_LEAD_MAX = float(os.environ.get('OFFICE_LEG_LEAD', '1.2'))
MPC_MODE = int(os.environ.get('OFFICE_MPC', '0'))
MPC_DIRS = int(os.environ.get('OFFICE_MPC_DIRS', '24'))
MPC_STEPS = int(os.environ.get('OFFICE_MPC_STEPS', '14'))
MPC_DT = float(os.environ.get('OFFICE_MPC_DT', '0.06'))
MPC_SAFE = float(os.environ.get('OFFICE_MPC_SAFE', '0.40'))
MPC_LAMBDA = float(os.environ.get('OFFICE_MPC_LAM', '6.0'))
MPC_GIVEUP = float(os.environ.get('OFFICE_MPC_GIVEUP', '3.0'))
MPC_SPEEDS = (0.8, 1.6, 2.3, 2.9)
X_FRESH = 1
X_RECEDE = 1
X_ZRAMP = 2.5
EXPLORE = int(os.environ.get('OFFICE_EXPLORE', '1'))
EXPLORE_V = float(os.environ.get('OFFICE_EXPLORE_V', '0.75'))
EXPLORE_T0 = float(os.environ.get('OFFICE_EXPLORE_T0', '3.0'))
SEARCH_HOLD_S = float(os.environ.get('OFFICE_SEARCH_HOLD', '4.0'))
SEE_STRIDE = 4
SEE_BLOCK_G = float(os.environ.get('OFFICE_SEE_BLOCK', '0.016'))
OPEN_BINS = 24
OPEN_TAU = 0.2
OPEN_FOV = math.radians(90.0)
SELF_FREE = int(os.environ.get('OFFICE_SELF_FREE', '1'))
SELF_FREE_M = 0.35
SELF_FREE_R = float(os.environ.get('OFFICE_SELF_FREE_R', '0.12'))
_OM = None

def _office_map():
    global _OM
    if _OM is None:
        _OM = OfficeMap()
    return _OM

def _to_world(f, r, u, yaw):
    c, s = (math.cos(yaw), math.sin(yaw))
    return np.array([f * c + r * s, f * s - r * c, u])

def _to_body(w, yaw):
    c, s = (math.cos(yaw), math.sin(yaw))
    return np.array([c * w[0] + s * w[1], s * w[0] - c * w[1], w[2]])

def _derotate(vec, pitch, roll):
    cp, sp = (math.cos(pitch), math.sin(pitch))
    cr, sr = (math.cos(roll), math.sin(roll))
    x, y, z = vec
    return (cp * x + sp * sr * y + sp * cr * z, cr * y - sr * z, -sp * x + cp * sr * y + cp * cr * z)

def intercept_lead(rel, vt, speed):
    a = float(np.dot(vt, vt)) - speed * speed
    b = 2.0 * float(np.dot(rel, vt))
    c = float(np.dot(rel, rel))
    if abs(a) < 1e-09:
        return -c / b if abs(b) > 1e-09 and -c / b > 0.001 else None
    disc = b * b - 4.0 * a * c
    if disc < 0.0:
        return None
    root = math.sqrt(disc)
    ts = [t for t in ((-b - root) / (2.0 * a), (-b + root) / (2.0 * a)) if t > 0.001]
    if not ts:
        return None
    T = min(ts)
    return T if np.isfinite(T) and T < LEAD_MAX_S else None

class DroneFlightController:

    def __init__(self):
        self.om = _office_map() if MAP_VETO else None
        self.reset()

    def reset(self):
        self.t = 0.0
        self.rel = None
        self.vt = np.zeros(3)
        self.age = 99.0
        self.meas_t = -99.0
        self.confirm_t = -99.0
        self.confirmed = False
        self.pursuing = False
        self.aim = np.zeros(3)
        self.vcmd = np.zeros(3)
        self.z = SPAWN_Z
        self.att = [(0.0, 0.0, 0.0, 0.0)]
        self.last_box = None
        self.last_box_t = -99.0
        self.leg = []
        self._loc = None
        self._last_tgt = None
        self._x_prev_det_age = 1000000000.0
        self._pos = np.zeros(2)
        self._exp_hdg = None
        self._self_prev = None
        self._open = np.zeros(OPEN_BINS)
        self._open_n = np.zeros(OPEN_BINS)

    def _att_at(self, t_eff):
        best, out = (1e+18, self.att[-1])
        for e in self.att:
            d = abs(e[0] - t_eff)
            if d < best:
                best, out = (d, e)
        return (out[1], out[2], out[3])

    def _boxes(self, det, pitch, roll, yaw):
        out = []
        for i in range(min(int(det[0]), 2)):
            cx, cy, w, h, conf = det[2 + 5 * i:7 + 5 * i]
            if w <= 1e-06 or h <= 1e-06:
                continue
            depth = math.sqrt(FOCAL * TGT_W / (float(w) * RES) * (FOCAL * TGT_H / (float(h) * RES)))
            a = (float(cx) - 0.5) * K
            b = (float(cy) - 0.5) * K
            f, lft, u = _derotate((depth + EYE_FWD, -a * depth, -b * depth + EYE_UP), pitch, roll)
            out.append((_to_world(f, -lft, u, yaw), float(conf)))
        return out

    def _update(self, det, v_self):
        det_age = float(det[1])
        pitch, roll, yaw = self._att_at(self.t - det_age)
        self.age += DT
        if self.rel is not None:
            self.rel = self.rel + (self.vt - v_self) * DT
            if self.age > STALE_S:
                self.vt *= 0.98
        if X_FRESH:
            _fresh = det_age < self._x_prev_det_age - 1e-09
            self._x_prev_det_age = det_age
            if not _fresh:
                return
        cand = self._boxes(det, pitch, roll, yaw)
        cand_raw = [tuple((float(v) for v in det[2 + 5 * i:7 + 5 * i])) for i in range(min(int(det[0]), 2)) if float(det[2 + 5 * i + 2]) > 1e-06 and float(det[2 + 5 * i + 3]) > 1e-06]
        if not cand:
            return
        held = self.rel if self.age < STALE_S else None
        best, pick, pick_box = (1e+18, None, None)
        for (rel, conf), raw in zip(cand, cand_raw):
            rel = rel - v_self * det_age
            if not 0.95 <= self.z + rel[2] <= 3.0:
                continue
            rng = float(np.linalg.norm(rel))
            if held is not None:
                cost = float(np.linalg.norm(rel - held))
                if cost > max(1.0, GATE_K * rng):
                    continue
            else:
                cost = 4.0 - conf
            if cost < best:
                best, pick, pick_box = (cost, rel, raw)
        if pick is None:
            return
        self.last_box = pick_box
        self.last_box_t = self.t
        if held is None:
            self.rel, self.vt = (pick, np.zeros(3))
            self.confirmed = self.t - self.confirm_t <= CONFIRM_S
        else:
            dt_m = max(self.t - self.meas_t, DT)
            err = pick - self.rel
            self.rel = self.rel + ALPHA * err
            self.vt = self.vt + BETA / dt_m * err
            n = float(np.linalg.norm(self.vt))
            if n > VT_MAX:
                self.vt *= VT_MAX / n
            self.confirmed = True
        self.confirm_t = self.meas_t = self.t
        self.age = 0.0
        self.leg.append((self.t, np.array([self._pos[0] + self.rel[0], self._pos[1] + self.rel[1], self.z + self.rel[2]])))
        cut = self.t - LEG_WINDOW_S
        while self.leg and self.leg[0][0] < cut:
            self.leg.pop(0)

    def _rollout_clear(self, here, vdes, horizon):
        v = self.vcmd.copy()
        p = np.array([here[0], here[1], here[2]], dtype=np.float64)
        worst = 9.9
        for _ in range(max(2, int(horizon / ROLL_DT))):
            dv = vdes - v
            n = float(np.linalg.norm(dv))
            cap = A_CMD * ROLL_DT
            v = v + (dv * (cap / n) if n > cap else dv)
            p = p + v * ROLL_DT
            c = float(self.om.clearance(p))
            if c < worst:
                worst = c
                if worst < VETO_CLEAR_M:
                    return worst
        return worst

    def _emergency_steer(self, vdes):
        loc = self._loc
        if loc is None or loc.p is None or loc.spread() > 0.45:
            return vdes
        sp = float(np.linalg.norm(vdes[:2]))
        if sp < 0.3:
            return vdes
        w = loc.estimate()
        here = np.array([w[0], w[1], self.z])
        reach = sp * VETO_HORIZON_S
        for deg in (0, 20, -20, 40, -40, 65, -65):
            a = math.radians(deg)
            c_, s_ = (math.cos(a), math.sin(a))
            d = np.array([vdes[0] * c_ - vdes[1] * s_, vdes[0] * s_ + vdes[1] * c_])
            n = float(np.linalg.norm(d))
            if n < 1e-06:
                return vdes
            p = here + np.array([d[0] / n * reach, d[1] / n * reach, 0.0])
            if self.om.path_clearance(here, p) > VETO_CLEAR_M:
                return np.array([d[0], d[1], vdes[2]])
        return vdes

    def _leg_velocity(self):
        if len(self.leg) < LEG_MIN_PTS:
            return None
        T = np.array([e[0] for e in self.leg])
        P = np.array([e[1] for e in self.leg])
        if float(T[-1] - T[0]) < LEG_MIN_SPAN_S:
            return None
        c = P.mean(axis=0)
        X = P - c
        try:
            u = np.linalg.svd(X, full_matrices=False)[2][0]
        except np.linalg.LinAlgError:
            return None
        along = X @ u
        tt = T - T.mean()
        denom = float(np.dot(tt, tt))
        if denom < 1e-09:
            return None
        speed = float(np.dot(tt, along) / denom)
        resid = X - np.outer(along, u)
        rms = float(np.sqrt((resid ** 2).sum(axis=1).mean()))
        v = u * speed
        n = float(np.linalg.norm(v))
        if n > VT_MAX:
            v = v * (VT_MAX / n)
        return (v, rms, len(self.leg))

    def _mpc(self, here, tgt_rel, tgt_vel, greedy):
        K, N = (MPC_DIRS, MPC_STEPS)
        ang = np.arange(K) * (2.0 * math.pi / K)
        dirs = np.stack([np.cos(ang), np.sin(ang)], axis=1)
        speeds = np.asarray(MPC_SPEEDS, dtype=np.float64)
        cand = (dirs[:, None, :] * speeds[None, :, None]).reshape(-1, 2)
        vz = float(np.clip(tgt_rel[2] * 1.8, -1.2, 1.6))
        C = len(cand)
        v = np.tile(self.vcmd[:2], (C, 1))
        pos = np.zeros((C, 2))
        tgt = np.tile(np.asarray(tgt_rel[:2], dtype=np.float64), (C, 1))
        best_d = np.full(C, 1000000000.0)
        pen = np.zeros(C)
        cap = A_CMD * MPC_DT
        for k in range(N):
            dv = cand - v
            n = np.linalg.norm(dv, axis=1, keepdims=True)
            v = v + np.where(n > cap, dv * (cap / np.maximum(n, 1e-09)), dv)
            pos = pos + v * MPC_DT
            th = min((k + 1) * MPC_DT, 0.6)
            t_k = tgt + np.asarray(tgt_vel[:2], dtype=np.float64) * th
            best_d = np.minimum(best_d, np.linalg.norm(pos - t_k, axis=1))
            world = np.column_stack([here[0] + pos[:, 0], here[1] + pos[:, 1], np.full(C, here[2] + vz * (k + 1) * MPC_DT)])
            clr = self.om.clearance(world)
            pen += np.maximum(0.0, MPC_SAFE - clr) ** 2
        cost = best_d + MPC_LAMBDA * pen
        i = int(np.argmin(cost))
        if pen[i] > MPC_GIVEUP:
            return greedy
        return np.array([cand[i, 0], cand[i, 1], greedy[2]])

    def _scan_open(self, rgb, yaw):
        if rgb is None:
            return
        g = np.asarray(rgb, dtype=np.float32)[::SEE_STRIDE, ::SEE_STRIDE]
        if g.ndim == 3:
            g = g.mean(axis=2)
        if g.shape[0] < 2:
            return
        prof = np.abs(np.diff(g, axis=0)).mean(axis=0)
        w = len(prof)
        cols = (np.arange(w) - w * 0.5) / (w * 0.5)
        bear = np.arctan(cols * math.tan(OPEN_FOV * 0.5))
        idx = ((yaw - bear) % (2.0 * math.pi) / (2.0 * math.pi) * OPEN_BINS).astype(np.int64) % OPEN_BINS
        tot = np.bincount(idx, weights=prof, minlength=OPEN_BINS)
        cnt = np.bincount(idx, minlength=OPEN_BINS)
        hit = cnt > 0
        obs = np.zeros(OPEN_BINS)
        obs[hit] = tot[hit] / cnt[hit]
        self._open[hit] = (1.0 - OPEN_TAU) * self._open[hit] + OPEN_TAU * obs[hit]
        self._open_n[hit] += 1

    def _explore(self, yaw):
        seen = self._open_n > 0
        if not seen.any():
            return None
        val = np.where(seen, self._open, -1.0)
        b = int(np.argmax(val))
        if val[b] < SEE_BLOCK_G:
            return None
        if self._exp_hdg is not None:
            cur = int(self._exp_hdg % (2.0 * math.pi) / (2.0 * math.pi) * OPEN_BINS) % OPEN_BINS
            if seen[cur] and self._open[cur] > 0.8 * val[b]:
                return self._exp_hdg
        self._exp_hdg = (b + 0.5) / OPEN_BINS * 2.0 * math.pi
        return self._exp_hdg

    def _observe_self_free(self):
        loc = self._loc
        if loc is None or loc.p is None:
            return
        if self._self_prev is None:
            self._self_prev = self._pos.copy()
            return
        d = float(np.linalg.norm(self._pos - self._self_prev))
        if d < SELF_FREE_M:
            return
        if d <= 4.0:
            loc.observe_free_segment(self._self_prev, self._pos, self.z, radius=SELF_FREE_R)
        self._self_prev = self._pos.copy()

    def _bearing(self, aim_body):
        if aim_body is None:
            return SEARCH_YAW
        b = math.atan2(float(aim_body[1]), max(float(aim_body[0]), 0.2))
        return float(np.clip(-b * YAW_K, -YAW_MAX, YAW_MAX))

    def act(self, observation):
        s = np.asarray(observation['state'], dtype=np.float64)
        self.t += DT
        pitch, roll = (float(s[0]), float(s[1]))
        yaw = math.atan2(float(s[2]), float(s[3]))
        v_self = _to_world(float(s[4]), float(s[5]), -float(s[6]), yaw)
        self.att.append((self.t - float(s[13]), pitch, roll, yaw))
        if len(self.att) > 40:
            self.att.pop(0)
        self.z = float(s[11]) + SPAWN_Z + v_self[2] * float(s[13])
        self._pos = self._pos + v_self[:2] * DT
        if MAP_VETO and self.om is not None:
            if self._loc is None:
                self._loc = MapLocalizer(self.om, n=LOC_N, seed=0)
            if self.z > 0.8 and int(round(self.t / DT)) % 5 == 0:
                self._loc.update(np.array([self._pos[0], self._pos[1], self.z]), self.z, float(s[10]), float(np.linalg.norm(v_self[:2])) * 0.1)
        if EXPLORE:
            self._scan_open(observation.get('rgb'), yaw)
        if SELF_FREE and MAP_VETO and (self._loc is not None):
            self._observe_self_free()
        self._update(s[15:27], v_self)
        if MAP_VETO and self._loc is not None and (self._loc.p is not None) and (self.rel is not None) and (self.age < 0.1):
            w = self._loc.estimate()
            cur = np.array([w[0] + self.rel[0], w[1] + self.rel[1]])
            self._loc.observe_free_point(cur, float(self.z + self.rel[2]))
            if SEG_OBS and self._last_tgt is not None:
                self._loc.observe_free_segment(self._last_tgt, cur, float(self.z + self.rel[2]))
            self._last_tgt = cur
        have = self.rel is not None and self.confirmed
        self.pursuing = have and self.age < (STALE_S if self.pursuing else FRESH_S)
        aim_rel = self.rel + self.vt * YAW_LEAD_S if self.rel is not None else None
        aim_body = _to_body(aim_rel, yaw) if aim_rel is not None else None
        vdes = np.zeros(3)
        if self.z < CLIMB_Z and self.t < 2.5:
            vdes[2] = 1.6
            yaw_cmd = self._bearing(aim_body if have and self.age < STALE_S else None)
            if CLIMB_CHASE > 0.0 and self.pursuing and (self.rel is not None):
                n = float(np.linalg.norm(self.rel[:2]))
                if n > 1e-06:
                    frac = float(np.clip(self.z / CLIMB_Z, 0.0, 1.0))
                    v = CLIMB_CHASE * frac
                    vdes[0] = self.rel[0] / n * v
                    vdes[1] = self.rel[1] / n * v
        elif self.pursuing:
            rng = float(np.linalg.norm(self.rel))
            if LEG_MODE:
                fit = self._leg_velocity()
                if fit is not None and fit[1] < LEG_MAX_RMS:
                    q = 1.0 - fit[1] / LEG_MAX_RMS
                    lead = T_LEAD + (LEG_LEAD_MAX - T_LEAD) * q
                    aim = self.rel + fit[0] * lead
                else:
                    aim = self.rel + self.vt * min(T_LEAD, rng / V_MAX)
            elif LEAD_MODE:
                T = intercept_lead(self.rel, self.vt, max(V_MAX * LEAD_SPEED_FRAC, 0.5))
                lead = T if T is not None else min(T_LEAD, rng / V_MAX)
                aim = self.rel + self.vt * lead
            else:
                aim = self.rel + self.vt * min(T_LEAD, rng / V_MAX)
            if rng < R_TERM:
                self.aim = self.aim + DT / max(DIR_TAU, DT) * (aim - self.aim)
                aim = self.aim
            else:
                self.aim = aim
            speed = min(V_MAX, math.sqrt(2.0 * A_EFF * max(rng - 0.05, 0.0)) + (max(float(np.dot(self.vt, self.rel)) / max(rng, 1e-06), V_CREEP) if X_RECEDE else max(float(np.linalg.norm(self.vt)), V_CREEP)))
            if R_COMMIT > 0.0 and rng < R_COMMIT and (self.age < 0.2):
                speed = max(speed, min(V_MAX, COMMIT_V))
            if self.age >= 0.2:
                speed *= STALE_MUL
            if ALIGN_GATE > 0.0 and aim_body is not None:
                ab = np.asarray(aim_body, dtype=np.float64)
                nb = float(np.linalg.norm(ab[:2]))
                align = float(ab[0]) / nb if nb > 1e-06 else 1.0
                if ALIGN_VERT > 0.0:
                    n3 = float(np.linalg.norm(ab))
                    if n3 > 1e-06:
                        align *= 1.0 - ALIGN_VERT * min(1.0, abs(float(ab[2])) / n3)
                speed *= float(np.clip(align, ALIGN_GATE, 1.0))
            n = float(np.linalg.norm(aim))
            if n > 1e-06:
                vdes = aim / n * speed
            yaw_cmd = self._bearing(aim_body)
            if R_VISUAL > 0.0 and rng < R_VISUAL and (self.last_box is not None) and (self.t - self.last_box_t < 0.25):
                cx, cy = (self.last_box[0], self.last_box[1])
                right = (cx - 0.5) * 2.0
                down = (cy - 0.5) * 2.0
                close = min(speed, V_TERM)
                body = np.array([close, right * K_VIS * close, -down * K_VIS * close])
                vdes = _to_world(body[0], body[1], body[2], yaw)
                yaw_cmd = float(np.clip(-right * YAW_K, -YAW_MAX, YAW_MAX))
        else:
            vdes[2] = float(np.clip((Z_CRUISE - self.z) * 1.2, -VZ_MAX, VZ_MAX))
            self.aim = np.zeros(3)
            yaw_cmd = self._bearing(aim_body if self.rel is not None and self.age < 1.5 else None)
            if REACQ_V > 0.0 and self.rel is not None and (self.age < REACQ_MAX_S):
                n = float(np.linalg.norm(self.rel[:2]))
                if n > 1e-06:
                    decay = max(0.0, 1.0 - self.age / REACQ_MAX_S)
                    v = REACQ_V * decay
                    vdes[0] = self.rel[0] / n * v
                    vdes[1] = self.rel[1] / n * v
            if EXPLORE and self.t > EXPLORE_T0 and (self.age >= SEARCH_HOLD_S):
                a = self._explore(yaw)
                if a is not None:
                    vdes[0] = math.cos(a) * EXPLORE_V
                    vdes[1] = math.sin(a) * EXPLORE_V
        if MPC_MODE and self.pursuing and (self.om is not None) and (self._loc is not None) and (self._loc.p is not None) and (self._loc.spread() <= 0.45) and (self.rel is not None):
            w = self._loc.estimate()
            vdes = self._mpc(np.array([w[0], w[1], self.z]), self.rel, self.vt, vdes)
        elif MAP_VETO and self.om is not None:
            vdes = self._emergency_steer(vdes)
        vdes[2] = min(float(vdes[2]), math.sqrt(2.0 * A_Z * max(Z_CEIL - self.z, 0.0)))
        vdes[2] = max(float(vdes[2]), -math.sqrt(2.0 * A_Z * max(self.z - Z_FLOOR, 0.0)))
        vdes[2] = float(np.clip(vdes[2], -VZ_MAX, VZ_MAX))
        if self.z < Z_FLOOR:
            vdes[2] = max(vdes[2], 0.9)
        elif self.z > Z_CEIL:
            vdes[2] = min(vdes[2], -0.9)
        dv = vdes - self.vcmd
        n = float(np.linalg.norm(dv))
        cap = A_CMD * DT
        if n > cap:
            dv *= cap / n
        if X_ZRAMP > 0.0:
            dv[2] = max(float(dv[2]), -X_ZRAMP * DT)
        self.vcmd = self.vcmd + dv
        lean = max(abs(pitch), abs(roll))
        if lean > TILT_GUARD:
            w = min(1.0, (lean - TILT_GUARD) / 0.25)
            b = self.vcmd * (1.0 - w) + v_self * w
            self.vcmd[0], self.vcmd[1] = (b[0], b[1])
        body = _to_body(self.vcmd, yaw)
        return np.array([np.clip(body[1] / 3.0, -1, 1), np.clip(body[0] / 3.0, -1, 1), np.clip(body[2] / 3.0, -1, 1), np.clip(yaw_cmd, -1, 1)], dtype=np.float32)
